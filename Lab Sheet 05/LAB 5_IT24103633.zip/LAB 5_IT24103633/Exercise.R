setwd("C:\\Users\\Aloka Fonseka\\Desktop\\LAB 5_IT24103633")

#1
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")
fix(Delivery_Times)

#2

names(Delivery_Times)<-c("X1")
attach(Delivery_Times)

histogram <- hist(X1, breaks = seq(20, 70, length = 10), right = FALSE,main = "Histogram for Delivery Times",
     xlab = "Delivery Times", ylab = "Frequency")

#4
freq <- histogram$counts
breaks<-round(histogram$breaks)
mids<-histogram$mids

cum_freq <- cumsum(freq)

plot(breaks[-1], cum_freq, type = "o",main = "Cumulative Frequency Polygon (Ogive)",
     xlab = "Delivery Times", ylab = "Cumulative Frequency")
